const $dot = document.getElementById("dot");
const $text = document.getElementById("status-text");
const $host = document.getElementById("host");

function setState(cls, text) {
  $dot.className = "dot " + cls;
  $text.textContent = text;
}

async function refresh() {
  const { gatewayHost } = await chrome.storage.local.get(["gatewayHost"]);
  const host = (gatewayHost || "").trim();
  $host.textContent = host && !host.includes("__") ? host : "not configured";
  if (!host || host.includes("__")) { setState("warn", "Not configured — open Settings"); return; }
  setState("unknown", "Checking…");
  chrome.runtime.sendMessage({ type: "health" }, (res) => {
    if (chrome.runtime.lastError || !res) { setState("bad", "Error"); return; }
    if (res.ok) {
      if (res.session === "expired") setState("warn", "Connected · Claude session expired — sign in again");
      else if (res.session === "none") setState("warn", "Connected · not signed in to Claude yet — open Claude and sign in");
      else setState("ok", "Connected · Claude session OK");
    }
    else if (res.reason === "wrong_build") setState("bad", "Wrong build: extension is not configured for " + host + (res.built ? " (built for " + res.built + ")" : " (unconfigured package)") + ". Use configure-prebuilt.sh <browser> " + host);
    else if (res.reason === "auth_failed") setState("bad", "Auth failed — check credentials");
    else if (res.reason === "unreachable") setState("bad", "Gateway unreachable");
    else setState("bad", "Error " + (res.status || res.reason || ""));
  });
}

document.getElementById("open").addEventListener("click", () => chrome.tabs.create({ url: "https://claude.ai" }));
document.getElementById("test").addEventListener("click", refresh);
document.getElementById("settings").addEventListener("click", () => chrome.runtime.openOptionsPage());

refresh();
